// **************************************************************************
// * This file is part of the FreeFileSync project. It is distributed under *
// * GNU General Public License: http://www.gnu.org/licenses/gpl.html       *
// * Copyright (C) Zenju (zenju AT gmx DOT de) - All Rights Reserved        *
// **************************************************************************

//dummy file for Visual Studio to compile precompiled header:
//associating pch with any other cpp file will trigger a full pch rebuild each time code is changed!