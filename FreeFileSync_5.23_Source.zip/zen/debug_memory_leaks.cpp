// **************************************************************************
// * This file is part of the FreeFileSync project. It is distributed under *
// * GNU General Public License: http://www.gnu.org/licenses/gpl.html       *
// * Copyright (C) Zenju (zenju AT gmx DOT de) - All Rights Reserved        *
// **************************************************************************

//-----------Memory Leak Detection--------------------------
//Usage: just include this file into a Visual Studio project


#ifdef _DEBUG //When _DEBUG is not defined, calls to _CrtSetDbgFlag are removed during preprocessing.
#define _CRTDBG_MAP_ALLOC //
#include <stdlib.h>       //keep this order: "The #include statements must be in the order shown here. If you change the order, the functions you use may not work properly."
#include <crtdbg.h>       //overwrites "operator new" ect; no need to include this in every compilation unit!
//http://msdn.microsoft.com/en-us/library/e5ewb1h3(v=vs.80).aspx

namespace
{
struct OnStartup
{
    OnStartup()
    {
        //note: wxWidgets also activates leak detection in "src/common/init.cpp" using a macro that is equivalent to:
        int flags = _CrtSetDbgFlag(_CRTDBG_REPORT_FLAG);
        _CrtSetDbgFlag(flags | _CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
    }

} dummy;
}
#endif //_DEBUG