// **************************************************************************
// * This file is part of the FreeFileSync project. It is distributed under *
// * GNU General Public License: http://www.gnu.org/licenses/gpl-3.0        *
// * Copyright (C) Zenju (zenju AT gmx DOT de) - All Rights Reserved        *
// **************************************************************************

#ifndef WX_FORM_BUILD_230948324234234
#define WX_FORM_BUILD_230948324234234

//pamper over wxFormBuilder "sub-optimal" code

#ifdef __GNUC__
    #pragma GCC diagnostic ignored "-Wunused-variable"
    #ifndef __clang__ //clang seems to define __GNUC__, but doesn't support this warning
        #pragma GCC diagnostic ignored "-Wunused-but-set-variable"
    #endif

#elif defined _MSC_VER
    #pragma warning(disable: 4189)
#endif

#endif //WX_FORM_BUILD_230948324234234
