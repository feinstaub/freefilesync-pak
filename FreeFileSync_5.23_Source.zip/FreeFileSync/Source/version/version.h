#ifndef VERSION_HEADER_434343489702544325
#define VERSION_HEADER_434343489702544325

namespace zen
{
const wchar_t currentVersion[] = L"5.23"; //internal linkage!
}

#endif
