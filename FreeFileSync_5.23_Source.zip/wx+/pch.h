// **************************************************************************
// * This file is part of the FreeFileSync project. It is distributed under *
// * GNU General Public License: http://www.gnu.org/licenses/gpl.html       *
// * Copyright (C) Zenju (zenju AT gmx DOT de) - All Rights Reserved        *
// **************************************************************************

#ifndef FFS_PRECOMPILED_HEADER
#define FFS_PRECOMPILED_HEADER

//pay attention when using this file: might cause issues!
#ifdef NDEBUG
#error do NOT use in release build!
#endif

//#####################################################

// basic wxWidgets headers
#ifndef WX_PRECOMP
#define WX_PRECOMP
#endif
#include <wx/wxprec.h> //includes <wx/msw/wrapwin.h>

//other wxWidgets headers
#include <wx/log.h>
#include <wx/grid.h>
#include <wx/animate.h>
#include <wx/app.h>
#include <wx/arrstr.h>
#include <wx/bitmap.h>
#include <wx/bmpbuttn.h>
#include <wx/button.h>
#include <wx/checkbox.h>
#include <wx/choice.h>
#include <wx/clipbrd.h>
#include <wx/cmdline.h>
#include <wx/colour.h>
#include <wx/config.h>
#include <wx/dc.h>
#include <wx/dialog.h>
//#include <wx/dir.h> -> MSVC: avoid annoying IntelliSense error: wxZipStreamLink
//#include <wx/zipstrm.h>
#include <wx/dnd.h>
#include <wx/file.h>
#include <wx/filename.h>
#include <wx/filepicker.h>
#include <wx/font.h>
#include <wx/frame.h>
#include <wx/gauge.h>
#include <wx/gdicmn.h>
#include <wx/grid.h>
#include <wx/hyperlink.h>
#include <wx/icon.h>
#include <wx/image.h>
#include <wx/intl.h>
#include <wx/log.h>
#include <wx/menu.h>
#include <wx/msgdlg.h>
#include <wx/panel.h>
#include <wx/radiobut.h>
#include <wx/settings.h>
#include <wx/sizer.h>
#include <wx/statbmp.h>
#include <wx/statbox.h>
#include <wx/statline.h>
#include <wx/stattext.h>
#include <wx/stdpaths.h>
#include <wx/stopwatch.h>
#include <wx/stream.h>
#include <wx/string.h>
#include <wx/textctrl.h>
#include <wx/thread.h>
#include <wx/utils.h>
#include <wx/wfstream.h>
#include <wx/scrolwin.h>
#include <wx/notebook.h>
#include <wx/help.h>
#include <wx/event.h>

//STL headers
#include <string>
#include <vector>
#include <set>
#include <map>
#include <queue>
#include <deque>
#include <stack>
#include <list>
#include <algorithm>
#include <functional>
#include <iterator>
#include <numeric>
#include <memory>
#include <utility>
#include <fstream>
#include <iostream>
#include <sstream>
#include <new>
#include <stdexcept>

//Boost


#endif //FFS_PRECOMPILED_HEADER
