// **************************************************************************
// * This file is part of the FreeFileSync project. It is distributed under *
// * GNU General Public License: http://www.gnu.org/licenses/gpl.html       *
// * Copyright (C) Zenju (zenju AT gmx DOT de) - All Rights Reserved        *
// **************************************************************************

#ifndef I18_N_HEADER_3843489325045
#define I18_N_HEADER_3843489325045

#include <string>
#include <memory>
#include <cstdint>
#include "string_tools.h"


//minimal layer enabling text translation - without platform/library dependencies!
#ifndef WXINTL_NO_GETTEXT_MACRO
#error WXINTL_NO_GETTEXT_MACRO must be defined to deactivate wxWidgets underscore macro
#endif

#define ZEN_TRANS_CONCAT_SUB(X, Y) X ## Y
#define _(s) zen::implementation::translate(ZEN_TRANS_CONCAT_SUB(L, s))
#define _P(s, p, n) zen::implementation::translate(ZEN_TRANS_CONCAT_SUB(L, s), ZEN_TRANS_CONCAT_SUB(L, p), n)
//source and translation are required to use %x as number placeholder
//for plural form, which will be substituted automatically!!!

namespace zen
{
//implement handler to enable program wide localizations: implement THREAD-SAFE ACCESS!
struct TranslationHandler
{
    virtual ~TranslationHandler() {}

    virtual std::wstring translate(const std::wstring& text) = 0; //simple translation
    virtual std::wstring translate(const std::wstring& singular, const std::wstring& plural, std::int64_t n) = 0;
};

void setTranslator(TranslationHandler* newHandler = nullptr); //takes ownership
TranslationHandler* getTranslator();













//######################## implementation ##############################
namespace implementation
{
inline
std::wstring translate(const std::wstring& text)
{
    return getTranslator() ? getTranslator()->translate(text) : text;
}

//translate plural forms: "%x day" "%x days"
//returns "1 day" if n == 1; "123 days" if n == 123 for english language
inline
std::wstring translate(const std::wstring& singular, const std::wstring& plural, std::int64_t n)
{
    assert(contains(plural, L"%x"));

    if (getTranslator())
    {
        std::wstring translation = getTranslator()->translate(singular, plural, n);
        assert(!contains(translation, L"%x"));
        return translation;
    }
    else
        return replaceCpy(std::abs(n) == 1 ? singular : plural, L"%x", zen::numberTo<std::wstring>(n));
}

template <class T> inline
std::wstring translate(const std::wstring& singular, const std::wstring& plural, T n)
{
    static_assert(sizeof(n) <= sizeof(std::int64_t), "");
    return translate(singular, plural, static_cast<std::int64_t>(n));
}

inline
std::unique_ptr<TranslationHandler>& globalHandler()
{
    static std::unique_ptr<TranslationHandler> inst; //external linkage even in header!
    return inst;
}
}

inline
void setTranslator(TranslationHandler* newHandler) { implementation::globalHandler().reset(newHandler); } //takes ownership

inline
TranslationHandler* getTranslator() { return implementation::globalHandler().get(); }
}

#endif //I18_N_HEADER_3843489325045
