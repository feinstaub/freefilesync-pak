// **************************************************************************
// * This file is part of the FreeFileSync project. It is distributed under *
// * GNU General Public License: http://www.gnu.org/licenses/gpl.html       *
// * Copyright (C) Zenju (zenju AT gmx DOT de) - All Rights Reserved        *
// **************************************************************************

#ifndef TASKBAR_SEVEN_DLL_H
#define TASKBAR_SEVEN_DLL_H

#ifdef TASKBAR_SEVEN_DLL_EXPORTS
#define DLL_FUNCTION_DECLARATION extern "C" __declspec(dllexport)
#else
#define DLL_FUNCTION_DECLARATION extern "C" __declspec(dllimport)
#endif

#include <zen/build_info.h>


namespace tbseven
{
/*--------------
  |declarations|
  --------------*/

enum TaskBarStatus
{
    STATUS_NOPROGRESS,
    STATUS_INDETERMINATE,
    STATUS_NORMAL,
    STATUS_ERROR,
    STATUS_PAUSED
};


//COM needs to be initialized before calling any of these functions! CoInitializeEx/CoUninitialize

DLL_FUNCTION_DECLARATION
bool setStatus(void* hwnd, //HWND: window assciated to the taskbar icon
               TaskBarStatus status);


DLL_FUNCTION_DECLARATION
bool setProgress(void* hwnd, //HWND: window assciated to the taskbar icon
                 size_t current,
                 size_t total);

//if any of the functions above returns 'false', this message returns last error
DLL_FUNCTION_DECLARATION
void getLastError(wchar_t* buffer, size_t bufferSize);

/*----------
  |typedefs|
  ----------*/
typedef bool (*FunType_setStatus   )(void* hwnd, TaskBarStatus status);
typedef bool (*FunType_setProgress )(void* hwnd, size_t current, size_t total);
typedef void (*FunType_getLastError)(wchar_t* buffer, size_t bufferSize);

/*--------------
  |symbol names|
  --------------*/
//(use const pointers to ensure internal linkage)
const char funName_setStatus   [] = "setStatus";
const char funName_setProgress [] = "setProgress";
const char funName_getLastError[] = "getLastError";

/*---------------
  |library names|
  ---------------*/
inline const wchar_t* getDllName() { return zen::is64BitBuild ? L"Taskbar7_x64.dll" : L"Taskbar7_Win32.dll"; }
}

#undef DLL_FUNCTION_DECLARATION

#endif //TASKBAR_SEVEN_DLL_H
