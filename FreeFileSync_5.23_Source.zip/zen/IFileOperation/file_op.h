// **************************************************************************
// * This file is part of the FreeFileSync project. It is distributed under *
// * GNU General Public License: http://www.gnu.org/licenses/gpl.html       *
// * Copyright (C) Zenju (zenju AT gmx DOT de) - All Rights Reserved        *
// **************************************************************************

#ifndef RECYCLER_DLL_H
#define RECYCLER_DLL_H

#ifdef FILE_OP_DLL_EXPORTS
#define DLL_FUNCTION_DECLARATION extern "C" __declspec(dllexport)
#else
#define DLL_FUNCTION_DECLARATION extern "C" __declspec(dllimport)
#endif

#include <zen/build_info.h>


namespace fileop
{
/*--------------
  |declarations|
  --------------*/

//COM needs to be initialized before calling any of these functions! CoInitializeEx/CoUninitialize
//minimum OS: Windows Vista or later

//return false to abort operation
typedef bool (*RecyclerCallback)(const wchar_t* filename, //current item; may be empty string!
                                 void* sink); //virtual function mechanism is not guaranteed to be compatible between different compilers, therefore we go the C-way

DLL_FUNCTION_DECLARATION
bool moveToRecycleBin(const wchar_t* fileNames[],
                      size_t         fileCount, //size of fileNames array
                      RecyclerCallback callback, //optional
                      void* sink);               //

DLL_FUNCTION_DECLARATION
bool copyFile(const wchar_t* sourceFile,
              const wchar_t* targetFile);

DLL_FUNCTION_DECLARATION
bool checkRecycler(const wchar_t* dirname, bool& isRecycler); //returns false on error

DLL_FUNCTION_DECLARATION
bool getLockingProcesses(const wchar_t* filename, const wchar_t*& procList); //get list of processes as single string, call freeString(procList) after use!

DLL_FUNCTION_DECLARATION
void freeString(const wchar_t* str);

//get last error message if any of the functions above fail
DLL_FUNCTION_DECLARATION
const wchar_t* getLastError(); //no nullptr check required!

/*----------
  |typedefs|
  ----------*/
typedef bool (*FunType_moveToRecycleBin)(const wchar_t* fileNames[],
                                         size_t fileCount,
                                         RecyclerCallback callback,
                                         void* sink);
typedef bool (*FunType_copyFile)(const wchar_t* sourceFile, const wchar_t* targetFile);
typedef bool (*FunType_checkRecycler)(const wchar_t* dirname, bool& isRecycler);
typedef bool (*FunType_getLockingProcesses)(const wchar_t* filename, const wchar_t*& procList);
typedef void (*FunType_freeString)(const wchar_t* str);
typedef const wchar_t* (*FunType_getLastError)();

/*--------------
  |symbol names|
  --------------*/
//(use const pointers to ensure internal linkage)
const char funName_moveToRecycleBin   [] = "moveToRecycleBin";
const char funName_copyFile           [] = "copyFile";
const char funName_checkRecycler      [] = "checkRecycler";
const char funName_getLockingProcesses[] = "getLockingProcesses";
const char funName_freeString         [] = "freeString";
const char funName_getLastError       [] = "getLastError";

/*---------------
  |library names|
  ---------------*/
inline const wchar_t* getDllName() { return zen::is64BitBuild ? L"FileOperation_x64.dll" : L"FileOperation_Win32.dll"; }
}

#undef DLL_FUNCTION_DECLARATION

#endif //RECYCLER_DLL_H
