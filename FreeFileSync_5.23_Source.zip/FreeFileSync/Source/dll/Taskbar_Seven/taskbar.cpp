// **************************************************************************
// * This file is part of the FreeFileSync project. It is distributed under *
// * GNU General Public License: http://www.gnu.org/licenses/gpl.html       *
// * Copyright (C) Zenju (zenju AT gmx DOT de) - All Rights Reserved        *
// **************************************************************************

#include "taskbar.h"
#include <map>
#include <string>

#define WIN32_LEAN_AND_MEAN
#include <zen/com_error.h>
#include <zen/com_ptr.h>

#include <ShObjIdl.h>

using namespace zen;


namespace
{
std::wstring lastErrorMessage;


ComPtr<ITaskbarList3> getInstance()
{
    ComPtr<ITaskbarList3> taskbarlist;

    HRESULT hr = ::CoCreateInstance(CLSID_TaskbarList,
                                    nullptr,
                                    CLSCTX_ALL,
                                    IID_PPV_ARGS(taskbarlist.init()));
    if (FAILED(hr))
    {
        lastErrorMessage = formatComError(L"Error calling \"CoCreateInstance\".", hr);
        return ComPtr<ITaskbarList3>();
    }

    return taskbarlist;
}
}
//##################################################################################################


bool tbseven::setStatus(void* hwnd, //HWND: window assciated to the taskbar icon
                        TaskBarStatus status)
{
    TBPFLAG flag = TBPF_NORMAL;
    switch (status)
    {
        case STATUS_NOPROGRESS:
            flag = TBPF_NOPROGRESS;
            break;
        case STATUS_INDETERMINATE:
            flag = TBPF_INDETERMINATE;
            break;
        case STATUS_NORMAL:
            flag = TBPF_NORMAL;
            break;
        case STATUS_ERROR:
            flag = TBPF_ERROR;
            break;
        case STATUS_PAUSED:
            flag = TBPF_PAUSED;
            break;
    }

    ComPtr<ITaskbarList3> taskbarlist = getInstance();
    if (!taskbarlist) //error msg already set
        return false;

    HRESULT hr = taskbarlist->SetProgressState(static_cast<HWND>(hwnd),  //[in]  HWND hwnd,
                                               flag); //[in]  TBPFLAG tbpFlags
    if (FAILED(hr))
    {
        lastErrorMessage = formatComError(L"Error calling \"SetProgressState\".", hr);
        return false;
    }

    return true;
}


bool tbseven::setProgress(void* hwnd, //HWND: window assciated to the taskbar icon
                          size_t current,
                          size_t total)
{
    ComPtr<ITaskbarList3> taskbarlist = getInstance();
    if (!taskbarlist) //error msg already set
        return false;

    HRESULT hr = taskbarlist->SetProgressValue(
                     static_cast<HWND>(hwnd), //[in]  HWND hwnd,
                     current, //[in]  ULONGLONG ullCompleted,
                     total);  //[in]  ULONGLONG ullTotal
    if (FAILED(hr))
    {
        lastErrorMessage = formatComError(L"Error calling \"SetProgressValue\".", hr);
        return false;
    }

    return true;
}


void tbseven::getLastError(wchar_t* buffer, size_t bufferSize)
{
    if (bufferSize > 0)
    {
        size_t endPos = lastErrorMessage.copy(buffer, bufferSize - 1);
        buffer[endPos] = 0;
    }
}
