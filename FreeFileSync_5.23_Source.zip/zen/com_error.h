// **************************************************************************
// * This file is part of the FreeFileSync project. It is distributed under *
// * GNU General Public License: http://www.gnu.org/licenses/gpl.html       *
// * Copyright (C) Zenju (zenju AT gmx DOT de) - All Rights Reserved        *
// **************************************************************************

#ifndef COM_ERROR_HEADER_88425703425254
#define COM_ERROR_HEADER_88425703425254

#include <cstdio>
#include "sys_error.h"

namespace zen
{
std::wstring formatComError(const std::wstring& msg, HRESULT hr);

//Convenience Macros checking for COM errors:

#define ZEN_COM_CHECK(func) ZEN_COM_CHECK_IMPL(func, #func) //throw SysError
/*
Example: ZEN_COM_CHECK(backupComp->InitializeForBackup());

Equivalent to:
{
    HRESULT hrInternal = backupComp->InitializeForBackup();
    if (FAILED(hrInternal))
        throw SysError(formatComError(L"Error calling \"backupComp->InitializeForBackup()\".", hrInternal));
}
*/

#define ZEN_COM_ASSERT(obj) ZEN_COM_ASSERT_IMPL(obj, #obj) //throw SysError
/*
Example: ZEN_COM_ASSERT(obj);

Equivalent to:
    if (!obj)
		throw SysError(formatComError(L"Assertion failed: \"obj\".", E_FAIL));
*/






//################# implementation #####################
namespace impl
{
inline
std::wstring formatWin32Message(DWORD dwMessageId) //return empty string on error
{
    LPWSTR buffer = nullptr;
    if (::FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM    |
                        FORMAT_MESSAGE_MAX_WIDTH_MASK |
                        FORMAT_MESSAGE_IGNORE_INSERTS | //important: without this flag ::FormatMessage() will fail if message contains placeholders
                        FORMAT_MESSAGE_ALLOCATE_BUFFER, nullptr, dwMessageId, 0, reinterpret_cast<LPWSTR>(&buffer), 0, nullptr) != 0)
        if (buffer) //just to be sure
        {
            ZEN_ON_SCOPE_EXIT(::LocalFree(buffer));
            return buffer;
        }
    return std::wstring();
}


inline
std::wstring numberToHexString(long number)
{
    wchar_t buffer[100] = {};
    const int charsWritten = ::swprintf(buffer, 100, L"0x%08x", static_cast<int>(number));
    return charsWritten > 0 ? std::wstring(buffer, charsWritten) : std::wstring();
}


namespace
{
std::wstring formatFacility(HRESULT hr)
{
    switch (HRESULT_FACILITY(hr))
    {
        case FACILITY_XPS:
            return L"XPS";
        case FACILITY_WINRM:
            return L"Windows Resource Manager";
        case FACILITY_WINDOWSUPDATE:
            return L"Windows Update";
        case FACILITY_WINDOWS_DEFENDER:
            return L"Windows Defender Component";
        case FACILITY_WINDOWS_CE:
            return L"Windows CE";
        case FACILITY_WINDOWS:
            return L"Windows Subsystem";
        case FACILITY_USERMODE_VOLMGR:
            return L"User Mode Volume Manager";
        case FACILITY_USERMODE_VIRTUALIZATION:
            return L"User Mode Virtualization Subsystem";
        case FACILITY_USERMODE_VHD:
            return L"User Mode Virtual Hard Disk Support";
        case FACILITY_URT:
            return L".NET CLR";
        case FACILITY_UMI:
            return L"Ubiquitous Memoryintrospection Service";
        case FACILITY_UI:
            return L"UI";
        case FACILITY_TPM_SOFTWARE:
            return L"Trusted Platform Module Applications";
        case FACILITY_TPM_SERVICES:
            return L"Trusted Platform Module Services";
        case FACILITY_SXS:
            return L"Side-by-side Servicing";
        case FACILITY_STORAGE:
            return L"OLE Storage";
        case FACILITY_STATE_MANAGEMENT:
            return L"State Management Services";
        case FACILITY_SCARD:
            return L"Smart-card Subsystem";
        case FACILITY_SHELL:
            return L"User Shell";
        case FACILITY_SETUPAPI:
            return L"Setup API";
        case FACILITY_SECURITY:
            return L"Security API Layer";
        case FACILITY_SDIAG:
            return L"System Diagnostics";
        case FACILITY_RPC:
            return L"RPC Subsystem";
        case FACILITY_RAS:
            return L"RAS";
        case FACILITY_PLA:
            return L"Performance Logs and Alerts";
        case FACILITY_OPC:
            return L"Open Connectivity Service";
        case FACILITY_WIN32:
            return L"Win32";
        case FACILITY_CONTROL:
            return L"Control Mechanism";
        case FACILITY_WEBSERVICES:
            return L"Web Services";
        case FACILITY_NDIS:
            return L"Network Driver Interface";
        case FACILITY_METADIRECTORY:
            return L"Microsoft Identity Server";
        case FACILITY_MSMQ:
            return L"Microsoft Message Queue";
        case FACILITY_MEDIASERVER:
            return L"Windows Media Server";
        case FACILITY_MBN:
            return L"MBN";
        case FACILITY_INTERNET:
            return L"Wininet";
        case FACILITY_ITF:
            return L"COM/OLE Interface Management";
        case FACILITY_USERMODE_HYPERVISOR:
            return L"Usermode Hypervisor Components";
        case FACILITY_HTTP:
            return L"HTTP Support";
        case FACILITY_GRAPHICS:
            return L"Graphics Drivers";
        case FACILITY_FWP:
            return L"Firewall Platform";
        case FACILITY_FVE:
            return L"Full volume encryption";
        case FACILITY_USERMODE_FILTER_MANAGER:
            return L"User Mode Filter Manager";
        case FACILITY_DPLAY:
            return L"Direct Play";
        case FACILITY_DISPATCH:
            return L"COM Dispatch";
        case FACILITY_DIRECTORYSERVICE:
            return L"Active Directory";
        case FACILITY_CONFIGURATION:
            return L"Configuration Services";
        case FACILITY_COMPLUS:
            return L"COM+";
        case FACILITY_USERMODE_COMMONLOG:
            return L"Common Logging Support";
        case FACILITY_CMI:
            return L"Configuration Management Infrastructure";
        case FACILITY_CERT:
            return L"Certificate";
        case FACILITY_BCD:
            return L"Boot Configuration Database";
        case FACILITY_BACKGROUNDCOPY:
            return L"Background Copy Control";
        case FACILITY_ACS:
            return L"Audit Collection Service";
        case FACILITY_AAF:
            return L"Microsoft Agent";
        default:
            return L"Unknown";
    }
}
}
}


std::wstring formatComError(const std::wstring& msg, long long hr); //not implemented! intentional overload ambiguity to catch usage errors with HRESULT!


inline
std::wstring formatComError(const std::wstring& msg, HRESULT hr)
{
    std::wstring output(msg);
    output += L"\n";

    //don't use _com_error(hr).ErrorMessage(): internally this is nothing more than a call to ::FormatMessage()
    std::wstring win32Msg = impl::formatWin32Message(hr);
    if (!win32Msg.empty())  //empty string on error
        output += win32Msg + L"\n" + L"HRESULT: " + impl::numberToHexString(hr);
    else
        output += L"HRESULT: " + impl::numberToHexString(hr) + L", " + L"Facility: " + impl::formatFacility(hr);
    //don't bluntly interpret as Win32 error code HRESULT_CODE(hr), too often misleading!
    //http://blogs.msdn.com/b/oldnewthing/archive/2006/11/03/942851.aspx

    return output;
}


#define ZEN_COM_CHECK_IMPL(func, txt) \
    {                                 \
        HRESULT hrInternal = func;    \
        if (FAILED(hrInternal))		  \
            throw zen::SysError(formatComError(std::wstring(L"Error calling \"") + L ## txt + L"\".", hrInternal)); \
    }

#define ZEN_COM_ASSERT_IMPL(obj, txt) if (!(obj)) throw zen::SysError(formatComError(std::wstring(L"Assertion failed: \"") + L ## txt + L"\".", E_FAIL));
}
#endif //COM_ERROR_HEADER_88425703425254
