// **************************************************************************
// * This file is part of the FreeFileSync project. It is distributed under *
// * GNU General Public License: http://www.gnu.org/licenses/gpl.html       *
// * Copyright (C) Zenju (zenju AT gmx DOT de) - All Rights Reserved        *
// **************************************************************************

#ifndef LOAD_DLL_HEADER_0312463214872163832174
#define LOAD_DLL_HEADER_0312463214872163832174

namespace dll
{
void setWin32Error(unsigned long lastError);

//NOTE: uses ::GetModuleHandle => call for system DLLs only!
template <class Func>
class SysDllFun
{
public:
    SysDllFun(const wchar_t* systemLibrary, const char* functionName) :
        fun(reinterpret_cast<Func>(loadSymbol(systemLibrary, functionName))) {}

    operator Func() const { return fun; }

private:
    Func fun;
};















void* /*FARPROC*/ loadSymbol(const wchar_t* libraryName, const char* functionName);
}

#endif //LOAD_DLL_HEADER_0312463214872163832174
