// **************************************************************************
// * This file is part of the FreeFileSync project. It is distributed under *
// * GNU General Public License: http://www.gnu.org/licenses/gpl.html       *
// * Copyright (C) Zenju (zenju AT gmx DOT de) - All Rights Reserved        *
// **************************************************************************

#ifndef SHADOWCOPY_H_14837413434
#define SHADOWCOPY_H_14837413434

#ifdef SHADOWDLL_EXPORTS
#define DLL_FUNCTION_DECLARATION extern "C" __declspec(dllexport)
#else
#define DLL_FUNCTION_DECLARATION extern "C" __declspec(dllimport)
#endif

#include <zen/build_info.h>
#include <zen/win_ver.h>


class IVssBackupComponents;

namespace shadow
{
/*--------------
  |declarations|
  --------------*/

//COM needs to be initialized before calling any of these functions! CoInitializeEx/CoUninitialize
struct ShadowData;
typedef ShadowData* ShadowHandle;

//volumeName *must* end with "\"
DLL_FUNCTION_DECLARATION
ShadowHandle createShadowCopy(const wchar_t* volumeName); //returns nullptr on failure!

//release the backupHandle after shadow copy is not needed anymore!
DLL_FUNCTION_DECLARATION
void releaseShadowCopy(ShadowHandle handle);

DLL_FUNCTION_DECLARATION
const wchar_t* getShadowVolume(ShadowHandle handle); //never fails, returns shadowVolName, never ending with "\"

//get last error message if any of the functions above fail
DLL_FUNCTION_DECLARATION
const wchar_t* getLastError(); //no nullptr check required!
//##########################################################################################


/*----------
  |typedefs|
  ----------*/
typedef ShadowHandle   (*FunType_createShadowCopy )(const wchar_t* volumeName);
typedef void           (*FunType_releaseShadowCopy)(ShadowHandle handle);
typedef const wchar_t* (*FunType_getShadowVolume  )(ShadowHandle handle);
typedef const wchar_t* (*FunType_getLastError)();

/*--------------
  |symbol names|
  --------------*/
//(use const pointers to ensure internal linkage)
const char funName_createShadowCopy [] = "createShadowCopy";
const char funName_releaseShadowCopy[] = "releaseShadowCopy";
const char funName_getShadowVolume  [] = "getShadowVolume";
const char funName_getLastError     [] = "getLastError";
/*---------------
  |library names|
  ---------------*/

inline
const wchar_t* getDllName()
{
    // distinguish a bunch of VSS builds: we use XP, Server 2003 and Server 2008 R2 implementations...
    // VSS version and compatibility overview: http://msdn.microsoft.com/en-us/library/aa384627(VS.85).aspx

    if (zen::win7OrLater()) //Windows Server 2008 R2 or Windows 7
        return zen::is64BitBuild ?
               L"Shadow_Windows7_x64.dll" :
               L"Shadow_Windows7_Win32.dll";
    //else if (vistaOrLater()) -> skip Windows Server 2008 and Windows Vista
    //			   ;
    else if (zen::winServer2003orLater()) //Windows Server 2003 and Windows Server 2003 R2
        return zen::is64BitBuild ?
               L"Shadow_Server2003_x64.dll" :
               L"Shadow_Server2003_Win32.dll";
    else //Windows XP
        return zen::is64BitBuild ?
               L"Shadow_XP_x64.dll" :
               L"Shadow_XP_Win32.dll";
}
}

#undef DLL_FUNCTION_DECLARATION

#endif //SHADOWCOPY_H_14837413434
