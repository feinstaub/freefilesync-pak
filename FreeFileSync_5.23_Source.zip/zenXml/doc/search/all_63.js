var searchData=
[
  ['col',['col',['../structzen_1_1_xml_parsing_error.html#a4a37dc48883337499804a9dc791669fd',1,'zen::XmlParsingError']]]
];
