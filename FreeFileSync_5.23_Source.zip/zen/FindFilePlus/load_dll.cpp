// **************************************************************************
// * This file is part of the FreeFileSync project. It is distributed under *
// * GNU General Public License: http://www.gnu.org/licenses/gpl.html       *
// * Copyright (C) Zenju (zenju AT gmx DOT de) - All Rights Reserved        *
// **************************************************************************

#include "load_dll.h"
#define WIN32_LEAN_AND_MEAN
#include <zen/win.h>

void* /*FARPROC*/ dll::loadSymbol(const wchar_t* libraryName, const char* functionName)
{
    return ::GetProcAddress(::GetModuleHandle(libraryName), functionName);
    //cleanup neither required nor allowed (::FreeLibrary())

}
//note: void* and FARPROC function pointer have same binary size on Windows


void dll::setWin32Error(unsigned long lastError)
{
    ::SetLastError(lastError);
}
