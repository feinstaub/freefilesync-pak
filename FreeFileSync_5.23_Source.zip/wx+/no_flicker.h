// **************************************************************************
// * This file is part of the FreeFileSync project. It is distributed under *
// * GNU General Public License: http://www.gnu.org/licenses/gpl.html       *
// * Copyright (C) Zenju (zenju AT gmx DOT de) - All Rights Reserved        *
// **************************************************************************

#ifndef NO_FLICKER_HEADER_893421590321532
#define NO_FLICKER_HEADER_893421590321532

#include <wx/textctrl.h>
#include <wx/stattext.h>

namespace zen
{
inline
void setText(wxTextCtrl& control, const wxString& newText, bool* additionalLayoutChange = nullptr)
{
    const wxString& label = control.GetValue(); //perf: don't call twice!
    if (additionalLayoutChange && !*additionalLayoutChange) //never revert from true to false!
        *additionalLayoutChange = label.length() != newText.length(); //avoid screen flicker: update layout only when necessary

    if (label != newText)
        control.ChangeValue(newText);
}

inline
void setText(wxStaticText& control, wxString newText, bool* additionalLayoutChange = nullptr)
{
#ifdef ZEN_WIN
    //wxStaticText handles ampersands incorrectly: https://sourceforge.net/p/freefilesync/bugs/279/
    replace(newText, L'&', L"&&");
#endif

    const wxString& label = control.GetLabel(); //perf: don't call twice!
    if (additionalLayoutChange && !*additionalLayoutChange)
        *additionalLayoutChange = label.length() != newText.length(); //avoid screen flicker: update layout only when necessary

    if (label != newText)
        control.SetLabel(newText);
}
}

#endif //NO_FLICKER_HEADER_893421590321532
