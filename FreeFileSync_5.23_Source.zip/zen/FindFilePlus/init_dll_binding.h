// **************************************************************************
// * This file is part of the FreeFileSync project. It is distributed under *
// * GNU General Public License: http://www.gnu.org/licenses/gpl.html       *
// * Copyright (C) Zenju (zenju AT gmx DOT de) - All Rights Reserved        *
// **************************************************************************

#ifndef INIT_DLL_BINDING_HEADER_�018356031467832145
#define INIT_DLL_BINDING_HEADER_�018356031467832145

namespace findplus
{
//load and check dll binding at startup
bool initDllBinding(); //evaluate in ::DllMain() when attaching process
}

#endif //INIT_DLL_BINDING_HEADER_�018356031467832145
