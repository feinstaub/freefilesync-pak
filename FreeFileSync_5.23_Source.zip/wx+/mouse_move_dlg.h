// **************************************************************************
// * This file is part of the FreeFileSync project. It is distributed under *
// * GNU General Public License: http://www.gnu.org/licenses/gpl.html       *
// * Copyright (C) Zenju (zenju AT gmx DOT de) - All Rights Reserved        *
// **************************************************************************

#ifndef MOUSEMOVEWINDOW_H_INCLUDED
#define MOUSEMOVEWINDOW_H_INCLUDED

#include <wx/window.h>

namespace zen
{
/*
move dialog by mouse-dragging contained sub-windows: just attach to parent via new in constructor:

Syntax:
    new MouseMoveWindow(parent); //ownership passed to parent
*/
class MouseMoveWindow : public wxWindow //private wxEvtHandler
{
public:
    MouseMoveWindow(wxWindow& parent, bool includeParent = true); //parent including all relevant child elements

    virtual bool allowMove(const wxMouseEvent& event) { return true; }

private:
    void LeftButtonDown(wxMouseEvent& event);
};
}

#endif // MOUSEMOVEWINDOW_H_INCLUDED
