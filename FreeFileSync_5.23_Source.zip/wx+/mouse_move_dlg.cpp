// **************************************************************************
// * This file is part of the FreeFileSync project. It is distributed under *
// * GNU General Public License: http://www.gnu.org/licenses/gpl.html       *
// * Copyright (C) Zenju (zenju AT gmx DOT de) - All Rights Reserved        *
// **************************************************************************

#include "mouse_move_dlg.h"
#include <vector>
#include <zen/win.h> //includes "windows.h"
#include <wx/stattext.h>
#include <wx/statbmp.h>
#include <wx/statline.h>
#include <wx/animate.h>
#include <wx/panel.h>
#include <wx/gauge.h>
#include <wx/statusbr.h>
#include <wx/frame.h>
#include <wx/dialog.h>

using namespace zen;


namespace
{
template <class Fun> inline
void forEachChild(wxWindow& parent, Fun f)
{
    wxWindowList& wl = parent.GetChildren();
    for (auto it = wl.begin(); it != wl.end(); ++it) //yet another wxWidgets bug keeps us from using std::for_each
    {
        wxWindow& wnd = **it;
        f(wnd);
        forEachChild(wnd, f);
    }
}
}

MouseMoveWindow::MouseMoveWindow(wxWindow& parent, bool includeParent) : wxWindow(&parent, wxID_ANY)
{
    wxObjectEventFunction memFunMouseDown = wxMouseEventHandler(MouseMoveWindow::LeftButtonDown); //wxWidgets macros are obviously not C++11 ready
    auto connect = [&](wxWindow& wnd)
    {
        if (dynamic_cast<wxStaticText*>   (&wnd) || //redirect clicks on these "dead" controls to move dialog instead
            dynamic_cast<wxStaticBitmap*> (&wnd) ||
            dynamic_cast<wxAnimationCtrl*>(&wnd) ||
            dynamic_cast<wxGauge*>        (&wnd) ||
            dynamic_cast<wxStaticLine*>   (&wnd) ||
            dynamic_cast<wxStatusBar*>    (&wnd) ||
            dynamic_cast<wxPanel*>        (&wnd) ||
            dynamic_cast<wxFrame*>        (&wnd) ||
            dynamic_cast<wxDialog*>       (&wnd))
            wnd.Connect(wxEVT_LEFT_DOWN, memFunMouseDown, nullptr, this);
    };

    if (includeParent)
        connect(parent);
    forEachChild(parent, connect);

    Hide(); //this is just a dummy window so that its parent can have ownership
    Disable();
}


void MouseMoveWindow::LeftButtonDown(wxMouseEvent& event)
{
    if (GetParent() && allowMove(event))
    {
        ::ReleaseCapture();
        //::SendMessage(GetHwndOf(dialogToMove_), WM_NCLBUTTONDOWN, HTCAPTION, 0);
        ::SendMessage(static_cast<HWND>(GetParent()->GetHWND()), WM_NCLBUTTONDOWN, HTCAPTION, 0);

        return;
        //event.Skip(); -> swallow event, to avoid other windows losing focus
    }
    event.Skip();
}
