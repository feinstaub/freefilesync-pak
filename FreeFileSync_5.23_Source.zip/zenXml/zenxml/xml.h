﻿// **************************************************************************
// * This file is part of the zen::Xml project. It is distributed under the *
// * Boost Software License: http://www.boost.org/LICENSE_1_0.txt           *
// * Copyright (C) Zenju (zenju AT gmx DOT de) - All Rights Reserved        *
// **************************************************************************

#ifndef ZEN_XML_HEADER_349578228034572457454554
#define ZEN_XML_HEADER_349578228034572457454554

#include "bind.h"

/// The zen::Xml namespace
namespace zen {}

#endif //ZEN_XML_HEADER_349578228034572457454554