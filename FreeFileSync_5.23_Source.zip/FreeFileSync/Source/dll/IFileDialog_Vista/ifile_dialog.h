// **************************************************************************
// * This file is part of the FreeFileSync project. It is distributed under *
// * GNU General Public License: http://www.gnu.org/licenses/gpl.html       *
// * Copyright (C) Zenju (zenju AT gmx DOT de) - All Rights Reserved        *
// **************************************************************************

#ifndef IFILE_DIALOG_HEADER_916743921746324
#define IFILE_DIALOG_HEADER_916743921746324

#ifdef IFILE_DIALOG_VISTA_DLL_EXPORTS
#define DLL_FUNCTION_DECLARATION extern "C" __declspec(dllexport)
#else
#define DLL_FUNCTION_DECLARATION extern "C" __declspec(dllimport)
#endif

#include <zen/build_info.h>


namespace ifile
{
/*--------------
  |declarations|
  --------------*/

//COM needs to be initialized before calling any of these functions! CoInitializeEx/CoUninitialize
//Requires Windows Vista and later

typedef char GuidProxy[16]; //= Windows 128-bit GUID; we don't want to include "Guiddef.h" here!

DLL_FUNCTION_DECLARATION
void showFolderPicker(void* ownerWindow,              //in;  ==HWND
                      const wchar_t* defaultFolder,   //in, optional!
                      const GuidProxy* guid, //set nullptr by default: Windows stores dialog state (position, x, y coordinates, ect.) associated with the process executable name => use other GUID when needed
                      wchar_t*& selectedFolder, //out: call freeString() after use!
                      bool& cancelled,                //out
                      wchar_t*& errorMsg); //out, optional: call freeString() after use!

DLL_FUNCTION_DECLARATION
void freeString(const wchar_t* str);

/*----------
  |typedefs|
  ----------*/
typedef bool (*FunType_showFolderPicker)(void* ownerWindow,
                                         const wchar_t* defaultFolder,
                                         const GuidProxy* guid,
                                         wchar_t*& selectedFolder,
                                         bool& cancelled,
                                         wchar_t*& errorMsg);
typedef void (*FunType_freeString)(const wchar_t* str);

/*--------------
  |symbol names|
  --------------*/
//(use const pointers to ensure internal linkage)
const char funName_showFolderPicker[] = "showFolderPicker";
const char funName_freeString      [] = "freeString";

/*---------------
  |library names|
  ---------------*/
inline const wchar_t* getDllName() { return zen::is64BitBuild ? L"IFileDialog_Vista_x64.dll" : L"IFileDialog_Vista_Win32.dll"; }
}

#undef DLL_FUNCTION_DECLARATION

#endif //IFILE_DIALOG_HEADER_916743921746324
