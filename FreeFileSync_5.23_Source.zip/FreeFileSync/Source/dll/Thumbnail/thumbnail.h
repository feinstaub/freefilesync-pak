// **************************************************************************
// * This file is part of the FreeFileSync project. It is distributed under *
// * GNU General Public License: http://www.gnu.org/licenses/gpl.html       *
// * Copyright (C) Zenju (zenju AT gmx DOT de) - All Rights Reserved        *
// **************************************************************************

#ifndef THUMBNAIL_DLL_HEADER_487108471324
#define THUMBNAIL_DLL_HEADER_487108471324

#ifdef THUMBNAIL_DLL_EXPORTS
#define DLL_FUNCTION_DECLARATION extern "C" __declspec(dllexport)
#else
#define DLL_FUNCTION_DECLARATION extern "C" __declspec(dllimport)
#endif

#include <zen/build_info.h>
//#include <WinDef.h>

namespace thumb
{
/*
PREREQUISITES:

1. COM must be initialized for the current thread via ::CoInitialize(nullptr) or ::CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED),
   but NOT ::CoInitializeEx(nullptr, COINIT_MULTITHREADED) -> internal access violation crash!
2. call ::FileIconInit() on app start to remedy obscure errors like SHELL_E_WRONG_BITDEPTH (0x80270102)
   for certain file types, e.g. lnk, mpg - required on Windows 7 see http://msdn.microsoft.com/en-us/library/ms683212(v=VS.85).aspx
*/

/*--------------
  |declarations|
  --------------*/
struct ImageData //consider alignment!
{
    unsigned char* rgb; //rgb-byte order for use with wxImage
    unsigned char* alpha;
    int width;
    int height;
};

DLL_FUNCTION_DECLARATION
const ImageData* getThumbnail(const wchar_t* filename, int requestedSize); //return nullptr on failure, release after use
//Note: not all file types support thumbnails! implement fallback to file icon!

enum IconSizeType
{
    ICON_SIZE_16,
    ICON_SIZE_32,
    ICON_SIZE_48,
    ICON_SIZE_128,
    ICON_SIZE_256,
};
//"iconIndex" as returned by ::SHGetFileInfo()
DLL_FUNCTION_DECLARATION
const ImageData* getIconByIndex(int iconIndex, IconSizeType st); //return nullptr on failure, release after use

DLL_FUNCTION_DECLARATION
void releaseImageData(const ImageData* id);


/*----------
  |typedefs|
  ----------*/
typedef const ImageData* (*FunType_getThumbnail    )(const wchar_t* filename, int requestedSize);
typedef const ImageData* (*FunType_getIconByIndex  )(int iconIndex, IconSizeType st);
typedef void             (*FunType_releaseImageData)(const ImageData* id);


/*--------------
  |symbol names|
  --------------*/
//(use const pointers to ensure internal linkage)
const char funName_getThumbnail    [] = "getThumbnail";
const char funName_getIconByIndex  [] = "getIconByIndex";
const char funName_releaseImageData[] = "releaseImageData";

/*---------------
  |library names|
  ---------------*/
inline const wchar_t* getDllName() { return zen::is64BitBuild ? L"Thumbnail_x64.dll" : L"Thumbnail_Win32.dll"; }
}

#undef DLL_FUNCTION_DECLARATION

#endif //THUMBNAIL_DLL_HEADER_487108471324
